# APS CLI

APS is a specification for packaging, governing and distributing technical knowledge consumed by AI agents and developer tooling.

This repository provides the reference CLI for working with the APS Protocol.

## Problem

Modern AI coding agents often lack reliable, project-specific technical knowledge about:

- internal component libraries
- architecture rules
- APIs
- services
- domain conventions

Without this context, agents produce plausible but incorrect outputs.

## Solution

APS Protocol standardizes how technical knowledge is described, validated, governed, and distributed:

- providers expose structured knowledge
- resources describe technical capabilities
- provenance explains where knowledge comes from
- governance determines trust
- sync distributes context to agents

APS is not limited to npm packages. Packages are one distribution mechanism inside the protocol ecosystem.

## Architecture Overview

```text
Source Systems
      |
      v
APS Provider
      |
      v
APS Manifest + Resources
      |
      v
Governance Validation
      |
      v
Developer Agents
```

## CLI Usage

```bash
npm install -g aps-cli

aps discover

aps validate

aps governance

aps doctor

aps generate

aps sync
```

## Example Provider Layout

```text
package/

dist/
  aps/
    manifest.json
    components.json
```

## Maturity Levels

- Level 0: APS Compatible
- Level 1: APS Described
- Level 2: APS Governed
- Level 3: APS Enterprise Ready

## Current Status

Current implementation includes:

- provider discovery
- validation
- governance checks
- maturity evaluation
- evidence-based component generation
- agent context synchronization

Planned evolution includes:

- API and service generation
- richer extractors
- automated migrations

## Core Concepts

- APS Provider
- APS Manifest
- APS Resource
- APS Governance
- APS Generate
